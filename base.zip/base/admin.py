from django.contrib import admin
from .models import Plan

admin.site.register(Plan)